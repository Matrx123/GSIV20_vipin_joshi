import React from 'react';
import { BrowserRouter as Router, Switch, Route } from 'react-router-dom';
import MovieHome from '../src/Components/MovieHome';
import Detail from '../src/Components/Detail';


function App() {
  return (
    <Router>
      <Switch>
        <Route exact path="/" component={MovieHome} />
        <Route path="/detail" component={Detail} />
      </Switch>
    </Router>
  );
}

export default App;
