import React, { Component } from 'react';
import { getMovieDetail } from '../Lib/MovieApi';
import '../Styles/style.css';
import { IMAGE_PATH } from '../Constants/index';
import home from '../Images/home.svg';
import { Link } from 'react-router-dom';

class Detail extends Component {
    constructor(props) {
        super(props)
        this.state = {
            detail: {}
        }
    }
    componentDidMount() {
        getMovieDetail(this.props.location.state.movieID)
            .then(response => {
                this.setState({
                    detail: response,
                }, () => {
                    console.log(this.state.detail)
                })
            }).catch(error => {
            });

    }
    renderDetail = () => {
        return (
            <React.Fragment>
                <div className="det-Img">
                    {
                        (this.state.detail.poster_path != null)
                            ?
                            <img src={IMAGE_PATH + this.state.detail.poster_path} alt="notFound"></img>
                            :
                            <div className="notFound"></div>
                    }
                </div>
                <div className="muv-det">
                    <div className="title">
                        <h2>{this.state.detail.original_title}</h2>
                        <div className="year">
                            <h4>{new Date().getFullYear(this.state.detail.release_date)} | {this.state.detail.runtime} Min | {}</h4>
                        </div>
                        <div className="cast">
                            <h4>Cast: {}</h4>
                        </div>
                        <div className="description">
                            <h4>Description: {this.state.detail.overview}</h4>
                        </div>
                    </div>
                    <div className="rating">
                        <h3>({this.state.detail.vote_average})</h3>
                    </div>
                </div>
            </React.Fragment>
        );
    }
    render() {
        return (
            <div>
                <div className="header-container">
                    <div className="menu-container">
                        <div className="menu-area">
                            <div className="input-area-det">
                                <h1>Movie Details</h1>
                                <Link to={{
                                    pathname: "/"
                                }}>
                                    <img className="homeImg-det" src={home} alt="..."></img>
                                </Link>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="detail-grid">
                    {
                        this.renderDetail()
                    }
                </div>
            </div>
        );
    }
}
export default Detail;