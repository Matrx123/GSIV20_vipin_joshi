import React from 'react';
import { Link } from 'react-router-dom';
import { IMAGE_PATH } from '../Constants';
import '../Styles/style.css';

const CardView = (props) => <div className="article" title={props.original_title}>
    {
        (props.poster_path != null)
            ?
            <Link to={{
                pathname: "/detail",
                state: {
                    movieID: props.id
                }
            }}>
                <img src={IMAGE_PATH + props.poster_path} alt="notFound"></img>
            </Link>
            :
            <Link to={{
                pathname: "/detail",
                state: {
                    movieID: props.id
                }
            }}>
                <div className="notFound"></div>
            </Link>
    }
    <Link style={{ textDecoration: 'none', color: 'white' }} to={{
        pathname: "/detail",
        state: {
            movieID: props.id
        }
    }}>
        <div className="item-content">
            <div className="text">
                <h3>{props.original_title}</h3>
                <h4 className="rating">({props.vote_average})</h4>
            </div>
            <div className="desc">
                <p className="desc">{props.overview}</p>
            </div>
        </div>
    </Link>
</div>

export default CardView;