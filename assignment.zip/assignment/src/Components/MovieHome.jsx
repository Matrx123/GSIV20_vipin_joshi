
import React, { Component } from 'react';
import '../Styles/style.css';
import home from '../Images/home.svg';
import arrow from '../Images/Arrow.svg'
import CardView from './CardView';
import { connect } from 'react-redux';
import {movieAction, pagination, searchMovies} from '../Actions/Action';

class MovieHome extends Component {

    componentDidMount() {
        this.props.getMoviesReducer(this.props.page, this.props.query, this.props.movieData)
    }

    render() {
        return (
            <div>
                <div className="container">
                    <div className="header-container">
                        <div className="menu-container">
                            <div className="menu-area">
                                <div className="input-area">
                                    <input type="text" placeholder="Search" onChange={(e) => {this.props.searchBar(e.target.value === "" ? "a" : e.target.value , 1)}}></input>
                                    <img className="homeImg" src={home} alt="..."></img>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="listView">
                        {
                            (this.props.movieData.length === 0)
                                ?
                                <h1></h1>
                                :
                                <div className="list-container">
                                    <main className="grid">
                                        {
                                            this.props.movieData.map(item =>
                                                <CardView {...item} />)
                                        }
                                    </main>
                                </div>
                        }
                    </div>
                    <div className="infinite" onClick={() => {
                        this.props.pagination(this.props.page+1, this.props.query, this.props.movieData)
                    }}>
                        <a><img src={arrow} alt="..."></img></a>
                    </div>
                </div>
            </div>

        );
    }
}

const mapStateToProps = (state) => {
    return {
        query: state.query,
        page: state.page,
        movieData: state.movieData
    }
}

const mapDispatchToProps = (dispatch) =>{
    return{
        getMoviesReducer : (page, query, movieData) =>{dispatch(movieAction(page, query, movieData))},
        pagination : (page, query, movieData) =>{dispatch(pagination(page, query, movieData))},
        searchBar:(value, page) => {dispatch(searchMovies(value, page))}
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(MovieHome);