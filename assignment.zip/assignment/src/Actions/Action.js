import { API_BASE_URL, LANGUAGE, API_KEY, INCLUDE_ADULT } from '../Constants/index';

export const movieAction = (page, query, movieData) => {
    return (dispatch) => {
        fetch(API_BASE_URL + "/search/movie?api_key=" + API_KEY + "&language=en-US" + LANGUAGE + "&query=" + query + "&page=" + page + "&include_adult=" + INCLUDE_ADULT)
            .then(res => res.json())
            .then(res2 => {
                dispatch({
                    type: "SEARCH_MOVIES",
                    payload: [...movieData, ...res2.results],
                    page: page,
                    query: query
                })
            })
    }
}



export const pagination = (page, query, movieData) => {
    return (dispatch) => {
        fetch(API_BASE_URL + "/search/movie?api_key=" + API_KEY + "&language=en-US" + LANGUAGE + "&query=" + query + "&page=" + page + "&include_adult=" + INCLUDE_ADULT)
            .then(res => res.json())
            .then(res2 => {
                dispatch({
                    type: "PAGE",
                    payload: [...movieData, ...res2.results],
                    page: page,
                    query: query
                })
            })
    }
}

export const searchMovies = (query, page) => {
    return (dispatch) => {
        fetch(API_BASE_URL + "/search/movie?api_key=" + API_KEY + "&language=en-US" + LANGUAGE + "&query=" + query + "&page=" + page + "&include_adult=" + INCLUDE_ADULT)
            .then(res => res.json())
            .then(res2 => {
                dispatch({
                    type: "SEARCH_BY_TITLE",
                    payload: res2.results,
                    query: query,
                    page: page
                })
            })
    }
}



