const iState = {
    query: "a",
    page: 1,
    movieData: []
}

const reducer = (state = iState, action) => {
    if(action.type === "SEARCH_MOVIES"){
        return{
            page : action.page,
            movieData : action.payload,
            query:action.query

        }
    }
    if(action.type === "PAGE"){
        return{
            page : action.page,
            movieData : action.payload,
            query:action.query
        }
    }
    if(action.type === "SEARCH_BY_TITLE"){
        return{
            movieData : action.payload,
            query:action.query,
            page : action.page,
        }
    }
    return state;
}
export default reducer;