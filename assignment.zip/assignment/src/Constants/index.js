export const API_BASE_URL = "https://api.themoviedb.org/3";
export const API_KEY = "9534f41a9709bb52987ccb43c547b27f";
export const LANGUAGE = "en-us";
export const INCLUDE_ADULT = false;
export const IMAGE_PATH = "https://image.tmdb.org/t/p/original";